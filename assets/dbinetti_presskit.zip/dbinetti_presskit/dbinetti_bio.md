===
David Binetti
===

## Third Person
David Binetti is a six-time entrepreneur, having served on the founding team of companies ranging from consumer (QFN, later Intuit's [Quicken.com] (http://www.quicken.com)), to industrial (Arch Rock, acquired by [Cisco Systems] (http://www.cisco.com)), to government ([USA.gov] (http://www.usa.gov) (named USA Today's Site of the Year in 2000), to political (Votizen, acquired by [Brigade] (https://www.brigade.com)) — with three stints as Founder/CEO.  

Currently, David helps larger organizations innovate faster with less risk through [Innovation Options] (http://innovation-options), a valuation framework he created that calculates the ROI of Innovation, allowing Finance and Product to speak a common language in achieving a common goal.

David received his Bachelors with Highest Honors and University Distinction from UC Berkeley, and his MBA from UCLA, where he received the Deloitte Consulting Award for Top Thesis in his Graduating Class. He resides in San Carlos with his wife and two daughters, and when not enjoying time with them can be found [coding] (http://github.com/dbinetti), [singing] (https://www.youtube.com/watch?v=mH6AQAdPHkk), or [both] (http://barberscore.com).



## First Person
I'm a six-time entrepreneur, having served on the founding team of companies ranging from consumer (QFN, later Intuit's [Quicken.com] (http://www.quicken.com)), to industrial (Arch Rock, acquired by [Cisco Systems] (http://www.cisco.com)), to government ([USA.gov] (http://www.usa.gov), named USA Today's Site of the Year in 2000), to political (Votizen, acquired by [Brigade] (https://www.brigade.com)) — with three stints as Founder/CEO.  

Currently, I help larger organizations innovate faster with less risk through [Innovation Options] (http://innovation-options), a valuation framework I created that calculates the ROI of Innovation, allowing Finance and Product to speak a common language in achieving a common goal.

I received my Bachelors with Highest Honors and University Distinction from UC Berkeley, and my MBA from UCLA, where I received the Deloitte Consulting Award for Top Thesis in the Graduating Class. I reside in San Carlos with my wife and two daughters, and when not enjoying time with them I can be found [coding] (http://github.com/dbinetti), [singing] (https://www.youtube.com/watch?v=mH6AQAdPHkk), or [both] (http://barberscore.com).


## Appearances/Content
Please find below some links to some of my appearances, presentations and other original content.

[Innovation Options] (https://www.youtube.com/watch?v=_OJBSPCgz2I), presented at Lean Startup Conference, San Francisco 2015.

[When and How to Pivot] (http://www.slideshare.net/dbinetti/lean-startup-at-sxsw-votizen-pivot-case-study), presented at Web 2.0, SXSW, Startup Lessons Learned and other conferences.

[MSNBC PowerLunch] (http://video.cnbc.com/gallery/?video=3000067537), with Tyler Matheson

[Bloomberg TV] (http://www.bloomberg.com/video/87336342-votizen-allows-voters-to-connect-campaign.html), with Emily Chang

[USA.gov] (http://en.wikipedia.org/wiki/USA.gov), Wikipedia.org article on the creation of USA.gov.

[SLL Conf] (http://www.justin.tv/startuplessonslearned/b/286510301), presented at SLL Conf.

[Beware False Prophets] (http://blip.tv/lean-la/dave-binetti-beware-of-false-prophets-part-1-5347503), presented to the LeanLA conference.

[Lean and Venture] (http://www.slideshare.net/dbinetti/lean-andv-vc), presented to Lean Startup Circle, Bay Area

[TechCrunch Disrupt] (http://on.aol.com/video/votizen-voting-product-announcement-517173994), presentation with Ron Conway and Michael Arrington at TC Disrupt.

[Harvard Business Case] (http://newsle.com/article/0/83716369/) presented to Steve Blank's class at the Haas School of Business, and at the Stanford GSB. 


## Company Background
Find below a list of the companies for which I've worked (in reverse chronological order), and some short background on each.

### Votizen
I was Co-Founder and CEO of Votizen, started in 2009 and acquired by Causes.com in 2013.  My investors included Steve Blank, Eric Ries, Peter Thiel, Ron Conway, Aydin Senkut, Bessemer Venture Parters, Sean Parker, Ashton Kutcher and others.  I used the Lean Startup approach on Votizen from the outset.

### Sentilla
Sentilla produced hardware and for wireless sensor networks. Sometimes referred to as the "internet of things", Sentilla's goal was to connect physical devices (usually sensors) to the internet.  The technology was used mostly in data centers for energy management.  Sentilla was acquired by Ericsson in 2014; I left the company to start Votizen.

### Arch Rock
Arch Rock, like Sentilla, produced hardware for wireless sensor networks.  I was on the founding team of Arch Rock as their first Marketer and Product Manager and helped raise their first round of capital (from NEA and Shasta Ventures).  Arch Rock's customer base was a variety of automobile and other industrial manufacturers.  We focused on connecting sensors to the existing production systems, typically over legacy sensor protocols (like i2c, 1-wire, CANbus, MODbus and other proprietary technology.)  The company was acquired by Cisco Systems in 2008; I left to join Sentilla.

### Capitolix
I was founder and CEO of Capitolix, a CRM Application focused on government and political markets.  I ran Capitolix in a highly traditional, linear product development model and learned after the release that I had built something no one wanted.  Although the company was a total failure I do consider Capitolix the most valuable experience on my CV because those lessons led directly to my embrace of the Lean Startup approach.

### USA.gov
I was co-founder and CEO of USA.gov (formerly FirstGov).  USA.gov is the official portal of the US Government and the second-most trafficked government website behind the White House.  USA.gov was launched in a record-setting 87-days and was an example of implementation speed within the context of a large bureaucracy.  Our primary goal with USA.gov was to move fast within the context of the US Government.  USA.gov has since won numerous awards, including being named USA Today's Site of the Year for 2000 and is a recipient of the prestigious "Innovations in American Government" award from Harvard's John F. Kennedy School of Government.  I was also named to the Fed-100 representing the top 100 Executives in Federal Tech by FCW Magazine.  

### Intuit
I was part of the original seven-person team that produced QFN.com, later to become Quicken.com.  I was responsible for metrics and customer analytics.  The entire team didn't last long as Intuit was far more interested in protecting existing lines of business than exploring the wild world of the Internet (which was still quite new at the time.)  Still, it was wonderful to learn the ropes of effective Product Marketing and Management from what I consider to be (still) among the best in tech.
